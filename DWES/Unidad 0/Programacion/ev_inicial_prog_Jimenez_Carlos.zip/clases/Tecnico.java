package clases;

public class Tecnico extends Operario {

	public Tecnico(String nombre) {
		super(nombre);
	}
		
	public Tecnico(String nombre, double salario, int meses) {
		super(nombre, salario, meses);
	}
	
	
	
	@Override
	public String toString() {
		return "Empleado: " + getNombre() +
				", salario: " + getSalario() +
				", meses trabajados -> " + getMeses() + 
				" -> Operario -> Tecnico";
	}

}
