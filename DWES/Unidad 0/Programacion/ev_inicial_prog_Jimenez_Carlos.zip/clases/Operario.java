package clases;

public class Operario extends Empleado {

	public Operario(String nombre) {
		super(nombre);
	}

	public Operario(String nombre, double salario, int meses) {
		super(nombre, salario, meses);
	}

	@Override
	public String toString() {
		return "Empleado: " + getNombre() +
				", salario: " + getSalario() +
				", meses trabajados -> " + getMeses() + 
				" -> Operario";
	}
	
	
		
}
