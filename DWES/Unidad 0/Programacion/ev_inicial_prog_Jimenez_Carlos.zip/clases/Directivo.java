package clases;

public class Directivo extends Empleado {

	// Atributos adicionales
	
	private double plus;

	public Directivo(String nombre, double plus) {
		super(nombre);
		this.plus = plus;
	}

	
	// Constructores
	
	public Directivo(String nombre, double salario, int meses, double plus) {
		super(nombre, salario, meses);
		this.plus = plus;
	}

	public Directivo(String nombre, double salario, int meses) {
		super(nombre, salario, meses);
		this.plus = 10000;
	}

	
	// Set y get
	
	public double getPlus() {
		return plus;
	}


	public void setPlus(double plus) {
		this.plus = plus;
	}


	// To String
	
	@Override
	public String toString() {
		return "Empleado: " + getNombre() +
				", salario = " + getSalario() +
				", meses trabajados -> " + getMeses() + 
				", plus-> " + plus + 
				" -> Directivo";
	}
	
	
	// Calcular Indemnización
	
	@Override
	public double calcularIndemnizacion (char tipoDespido) {
		
		double indemnizacion = 0;
		double salarioRegulador = getSalario() / 365;
		double mesesTrabajados = (double) getMeses();
		// double añosTrabajados = Math.floor(mesesTrabajados/12);
		
		if (tipoDespido == 'I') {
			// double ind = 33 * añosTrabajados * salarioRegulador;
			double ind = 33 * mesesTrabajados / 12 *  salarioRegulador;
			double max = 720 * salarioRegulador; 
			if (ind < max ) {
				indemnizacion = ind;
			} else indemnizacion = max;
		}
		
		else {
			if (tipoDespido == 'O') {
				// double ind = 20 * añosTrabajados * salarioRegulador;
				double ind = 20 * mesesTrabajados / 12 * salarioRegulador;
				double max = 360 * salarioRegulador; 
				if (ind < max ) {
					indemnizacion = ind;
				} else indemnizacion = max;
			}
			else {
				System.out.println("Este tipo de despido no existe.");
				System.out.println("Inténtelo de nuevo");
			}
		}
		
		return indemnizacion + plus;
	}
	
}
