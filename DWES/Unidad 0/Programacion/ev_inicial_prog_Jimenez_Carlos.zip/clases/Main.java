package clases;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Generamos array
		
		Empleado arrayEmpleados[] = new Empleado[8];
		
		// Introducimos los datos:
		
		arrayEmpleados[0] = new Empleado("Juan Diego García Mesa");
		arrayEmpleados[1] = new Empleado("María Torres Luna",35000,12);
		arrayEmpleados[2] = new Directivo("Jorge Almagro Pérez", 1200000,30); 
		arrayEmpleados[3] = new Directivo("Lucía Bravo Delegadoz",175000,50,300000);
		arrayEmpleados[4] = new Operario("Maneul Sordo Luengo");
		arrayEmpleados[5] = new Operario("Mario Casado Muñoz",27000,180);
		arrayEmpleados[6] = new Tecnico("Laura Baena Luque");
		arrayEmpleados[7] = new Tecnico("Pablo Lomo Manco",25500,24);
		
			// En el ejemplo, Jorge Almagro cobra 200000. Por eso no cuadran los números.
		
		
		
		// Mostramos los datos de los despidos improcedentes
		
		System.out.println("Mostramos los datos de los despidos improcedentes: ");
		
		for (int n = 0; n <= 7; n++) {
			System.out.println(arrayEmpleados[n]);
			System.out.println("Coste indemnización improcedente: " 
			+ Math.round(arrayEmpleados[n].calcularIndemnizacion('I')*100.0)/100.0 + "€");
		}
		
		
		// Espaciamos un poco		
		System.out.println();
		
		
		// Mostramos los datos de los despidos objetivo
		
		System.out.println("Mostramos los datos de los despidos objetivos: ");
		
		for (int n = 0; n <= 7; n++) {
			System.out.println(arrayEmpleados[n]);
			System.out.println("Coste indemnización improcedente: " 
			+ Math.round(arrayEmpleados[n].calcularIndemnizacion('O')*100.0)/100.0 + "€");
		}
	}

}
