package clases;

public class Empleado {
	
	// Atributos
	
	private String nombre;
	private double salario;
	private int meses;
	
	
	// Constructores
	
	public Empleado(String nombre) {
		super();
		this.nombre = nombre;
		this.salario = 20000;
		this.meses = 1;
	}


	public Empleado(String nombre, double salario, int meses) {
		super();
		this.nombre = nombre;
		this.salario = salario;
		this.meses = meses;
	}

	
	
	// Getters y setters
	
	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public double getSalario() {
		return salario;
	}


	public void setSalario(double salario) {
		this.salario = salario;
	}


	public int getMeses() {
		return meses;
	}


	public void setMeses(int meses) {
		this.meses = meses;
	}


	
	// To String
	
	@Override
	public String toString() {
		return "Empleado: " + nombre + ", salario = " + salario +
				", meses trabajados -> " + meses;
	}
	
	
	// Calcular Indemnización
	
	public double calcularIndemnizacion (char tipoDespido) {
		
		double indemnizacion = 0;
		double salarioRegulador = salario / 365;
		double mesesTrabajados = (double) meses;
		// double añosTrabajados = Math.floor(mesesTrabajados/12);
		
		if (tipoDespido == 'I') {
			// double ind = 33 * añosTrabajados * salarioRegulador;
			double ind = 33 * mesesTrabajados / 12 *  salarioRegulador;
			double max = 720 * salarioRegulador; 
			if (ind < max ) {
				indemnizacion = ind;
			} else indemnizacion = max;
		}
		
		else {
			if (tipoDespido == 'O') {
				// double ind = 20 * añosTrabajados * salarioRegulador;
				double ind = 20 * mesesTrabajados / 12 * salarioRegulador;
				double max = 360 * salarioRegulador; 
				if (ind < max ) {
					indemnizacion = ind;
				} else indemnizacion = max;
			}
			else {
				System.out.println("Este tipo de despido no existe.");
				System.out.println("Inténtelo de nuevo");
			}
		}
		
		return indemnizacion;
	}

}
